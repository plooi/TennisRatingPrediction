/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ustaratingprediction;

import java.util.Arrays;
import looinn.BackPropogation;
import looinn.NeuralNetwork;
import ljs.gui.*;
import static ljs.Obj.*;
/**
 *
 * @author peter_000
 */
public class USTARatingPrediction 
{
    /*
    If, for example, a player has only three years of history, for the two years that were 
    preceeding their tennis (because 5 yrs of data are needed career their rating will be 
    assumed to be the same as the rating they started out with. Basically, if you can't
    find enough data, use basic logical reasoning (lol) to reason and make predictions as to what 
    their rating would have been.
    */
    public static void main(String[] args) 
    {
        /*NeuralNetwork nn = new NeuralNetwork(false,NeuralNetwork.SOFT_SIGMOID,NeuralNetwork.DEFAULT_ACTIVATE_EVERY_OTHER,(r,c,d)->Math.random()*3-1.5,5,10,10,10,1);
        BackPropogation b = new BackPropogation(nn);
        b.addData("ratings.txt");
        b.evolve();*/
        
        NeuralNetwork nn = NeuralNetwork.deserialize("best.nn");
        /*System.out.println(Arrays.toString(nn.evaluate(3,3,3,3.5,3.5))); */
        
        Window w = new Window();
        w.uponClosing(()->stop());
        int textBoxWidth = 50;
        int textBoxHeight = 50;
        TextBox[] previousFiveScores = new TextBox[5];
        for(int i : range(previousFiveScores))
        {
            w.add(previousFiveScores[i] = new TextBox());
            previousFiveScores[i].setBounds(i*textBoxWidth,0,textBoxWidth,textBoxHeight);
            
        }
        TextBox answerTextBox = new TextBox();
        answerTextBox.setBounds(textBoxWidth * (previousFiveScores.length+4), 0, textBoxWidth*3, textBoxHeight);
        
        Button b = new Button(()->
        {
           answerTextBox.setText(nn.evaluate(collectInput(previousFiveScores))[0] + "") ;
        });
        b.setBounds(textBoxWidth * previousFiveScores.length, 0, textBoxWidth*4, textBoxHeight);
        b.setLabel("Calculate Next Year's Rating ->");
        w.add(answerTextBox);
        w.add(b);
    }
    public static double[] collectInput(TextBox[] previousFiveScores)
    {
        double[] ret = new double[previousFiveScores.length];
        try
        {
            for(int i : range(previousFiveScores))
            {
                ret[i] = Double.parseDouble(previousFiveScores[i].getText());
            }
            return ret;
        }
        catch(Exception e){return new double[previousFiveScores.length];}
    }
    
}
