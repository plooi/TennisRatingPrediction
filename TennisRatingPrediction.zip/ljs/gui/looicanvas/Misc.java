package ljs.gui.looicanvas;

import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.ImageIcon;

/**
 * This class contains useful methods that deal with media (and we also have 
 * exitSystem()). These methods can be accessed through a LooiObject or by
 * calling the static methods referring to the class. This class is 
 * uninstantiable except by members of this package
 * @author peter_000
 */
public interface Misc
    {
        /**
         * Shuts down the entire program
         */
        public static void exitSystem()
            {
                System.exit(0); 
            }
        /**
         * Loads an image
         * @param path The file location of the image
         * @return The Image
         */
        public static Image loadImage(String path)
            {
                Image i = new ImageIcon(path).getImage();
                if(i.getHeight(null) < 0 || i.getWidth(null) < 0)
                {
                    throw new ImageLoadingError(path);
                }
                return i;
            }
        public static BufferedImage loadBufferedImage(String path)
            {
                Image i = new ImageIcon(path).getImage();
                if(i.getHeight(null) < 0 || i.getWidth(null) < 0)
                {
                    throw new ImageLoadingError(path);
                }
                BufferedImage bi = new BufferedImage(i.getWidth(null),i.getHeight(null),BufferedImage.TYPE_INT_ARGB);
                bi.getGraphics().drawImage(i,0,0,bi.getWidth(),bi.getHeight(),null);
                return bi;
            }
        public static class ImageLoadingError extends RuntimeException
        {
            private String path;
            public ImageLoadingError(String path)
            {
                this.path = path;
            }
            public String toString()
            {
                return "ImageLoadingError: Path " + path + " does not return an image.";
            }
        }
        /**
         * Loads a file
         * @param path The file location of the file
         * @return The File
         */
        public static File loadFile(String path)
            {
                return new File(path);
            }
        /**
         * Plays a sound
         * @param soundFile The sound in the form of a File
         */
        public static void playSound(File soundFile)
            {
                Clip clip;
                try 
                    {
                        clip = AudioSystem.getClip();
                        clip.open(AudioSystem.getAudioInputStream(soundFile));
                        clip.start();
                    } 
                catch (Exception e) {}
            }
        public static void beep()
        {
            Toolkit t = Toolkit.getDefaultToolkit();
            t.beep();
        }
        
    }