/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ljs.gui.looicanvas.gui_essentials;

import java.util.ArrayList;
import java.util.Comparator;

/**
 *
 * @author peter_000
 */
public class Rectangle extends GuiComponent
{
    public static final double
            DEFAULT_X = 0,
            DEFAULT_Y = 0,
            DEFAULT_WIDTH = 100,
            DEFAULT_HEIGHT = 100;
    public static final Background
            DEFAULT_BACKGROUND = Background.BLACK_BACKGROUND;
    
    
    private double width,height;
    private Background background;
    
    
    public Rectangle(double x, double y, double width, double height, Background background)
    {
        super(x,y);
        this.width = width;
        this.height = height;
        this.background = background;
        
    }
    public Rectangle()
    {
        this(DEFAULT_X,DEFAULT_Y,DEFAULT_WIDTH,DEFAULT_HEIGHT,DEFAULT_BACKGROUND);
    }
    public void add(GuiComponent g)
    {
        super.add(g);
        g.addPaintBoundary(this); 
    }
    public void remove(GuiComponent g)
    {
        super.remove(g);
        g.removePaintBoundary(this); 
    }
    
    public void setDimensions(double width, double height)
    {
        if(width == this.width && height == this.height)
            return;
        this.width = width;
        this.height = height;
        updatePaintBoundary();
    }
    public double getWidth()
    {
        return width;
    }
    public double getHeight()
    {
        return height;
    }
    public Background getBackground()
    {
        return background;
    }
    public void setBackground(Background background)
    {
        this.background = background;
    }
    public boolean touchingMouse()
    {
        
        return getInternalMouseX() >= getX() && getInternalMouseX() <= getX() + getWidth() && getInternalMouseY() >= getY() && getInternalMouseY() <= getY() + getHeight();
    }
    
    protected void looiPaint()
    {
        super.looiPaint();
        if(background.ofColor())
        {
            //System.out.println(background.getImage());
            setColor(background.getColor());
            fillRect(getX(),getY(),width,height);
        }
        else if(background instanceof PatternBackground)
        {
            drawImage(((PatternBackground)background).getImage(width,height),getX(),getY(),width,height);
        }
        else
        {
            drawImage(background.getImage(),getX(),getY(),width,height);
        }
    }
    public String toString()
    {
        return getClass() + ": x: " + getX() + " y: " + getY() + " width: " + width + " height: " + height + " background: " + background;
    }
}

