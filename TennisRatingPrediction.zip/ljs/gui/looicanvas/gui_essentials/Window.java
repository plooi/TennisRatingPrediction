/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ljs.gui.looicanvas.gui_essentials;

import java.awt.Color;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import ljs.gui.looicanvas.utilities.InputBoolean;

/**
 *
 * @author peter_000
 */
public class Window extends Rectangle
{
    public static final double DEFAULT_MINIMUM_WIDTH = 200;
    public static final double DEFAULT_MINIMUM_HEIGHT = 200;
    
    private double minimumWidth = DEFAULT_MINIMUM_WIDTH;
    private double minimumHeight = DEFAULT_MINIMUM_HEIGHT;
    public Window()
    {
        super();
        init();
    }
    public Window(double x, double y, double width, double height, Background background)
    {
        super(x,y,width,height,background);
        init();
    }
    private void init()
    {
        
    }
    public double getMinimumWidth(){return minimumWidth;}
    public double getMinimumHeight(){return minimumHeight;}
    public void setMinimumDimensions(double w, double h){minimumWidth = w; minimumHeight = h;}
    
    
    public class ExitButton extends Button
    {
        public static final double DEFAULT_MARGIN_TO_EDGE = 5;
        public static final double DEFAULT_WIDTH = 50;
        public static final double DEFAULT_HEIGHT = 50;
        public static final String DEFAULT_TEXT = "    X";
        private boolean stayWithUpperRightCorner = true;
        
        
        
        public ExitButton()
        {
            super(
                    Window.this.getWidth() - DEFAULT_WIDTH - DEFAULT_MARGIN_TO_EDGE,
                    DEFAULT_MARGIN_TO_EDGE,
                    DEFAULT_WIDTH,DEFAULT_HEIGHT,DEFAULT_TEXT,new Background(Color.RED));
            
        }
        public boolean isStayingWithUpperRightCorner(){return stayWithUpperRightCorner;}
        public void setStayWithUpperRightCorner(boolean b){stayWithUpperRightCorner = b;}
        protected void action()
        {
            Window.this.deactivate();
        }
        protected void looiStep()
        {
            super.looiStep();
            if(stayWithUpperRightCorner)
            {
                setPosition(Window.this.getX() + Window.this.getWidth() - DEFAULT_WIDTH - DEFAULT_MARGIN_TO_EDGE,Window.this.getY() + DEFAULT_MARGIN_TO_EDGE);
            }
        }
    }
    public static final InputBoolean<DecorationBar> DEFAULT_DECORATION_BAR_CAN_DRAG_CONDITION = GuiComponent::touchingMouseAndInFront;
    //Used to be this:
    /*public static final InputBoolean<DecorationBar> DEFAULT_DECORATION_BAR_CAN_DRAG_CONDITION = (bar) ->
    {
        return bar.touchingMouseAndInFront();
    };*/
    public static final Background DEFAULT_DECORATION_BAR_BACKGROUND = Background.LIGHT_GRAY_BACKGROUND;
    public class DecorationBar extends Rectangle
    {
        public static final double DEFAULT_HEIGHT = 60;
        private boolean dragging = false;
        private double dragXOffsetFromMouse;
        private double dragYOffsetFromMouse;
        private InputBoolean<DecorationBar> canDrag = DEFAULT_DECORATION_BAR_CAN_DRAG_CONDITION;
        private boolean sameWidthAsWindow = true;
        
        
        public DecorationBar()
        {
            super(0,0,Window.this.getWidth(),DEFAULT_HEIGHT,DEFAULT_DECORATION_BAR_BACKGROUND);
            
        }
        public boolean isSameWidthAsWindow(){return sameWidthAsWindow;}
        public void setSameWidthAsWindow(boolean b){sameWidthAsWindow = b;}
        protected void looiStep()
        {
            if(sameWidthAsWindow)
            {
                setDimensions(Window.this.getWidth(),getHeight());
            }

            if(dragging)
            {
                Window.this.setPosition(getInternalMouseX() + dragXOffsetFromMouse, getInternalMouseY() + dragYOffsetFromMouse);
            }
            if(mouseLeftPressed())
            {
                if(canDrag.check(this) == true)
                {
                    dragging = true;
                    dragXOffsetFromMouse = Window.this.getX() - getInternalMouseX();
                    dragYOffsetFromMouse = Window.this.getY() - getInternalMouseY();
                }
            }
            if(mouseLeftReleased())
            {
                dragging = false;
            }
        }
        
        
    }
    
    public class ResizingGadget extends Rectangle
    {
        public static final double
                DEFAULT_WIDTH = 50,
                DEFAULT_HEIGHT = 50;
                
        private boolean dragging = false;
        public ResizingGadget()
        {
            super(Window.this.getWidth() - DEFAULT_WIDTH,Window.this.getHeight() - DEFAULT_HEIGHT,DEFAULT_WIDTH,DEFAULT_HEIGHT,Background.WHITE_BACKGROUND);
        }
        
        protected void looiStep()
        {
            super.looiStep();
            
            if(dragging)
            {
                double futureWidth = getInternalMouseX() - Window.this.getX();
                double futureHeight = getInternalMouseY() - Window.this.getY();
                if(futureWidth < minimumWidth)
                {
                    futureWidth = minimumWidth;
                }
                if(futureHeight < minimumHeight)
                {
                    futureHeight = minimumHeight;
                }
                Window.this.setDimensions(futureWidth,futureHeight);
            }
            setPosition(Window.this.getX() + Window.this.getWidth() - DEFAULT_WIDTH,Window.this.getY() + Window.this.getHeight() - DEFAULT_HEIGHT);
            if(mouseLeftPressed())
            {
                if(touchingMouseAndInFront())
                {
                    dragging = true;
                }
            }
            if(mouseLeftReleased())
            {
                dragging = false;
            }
        }
        
    }
}
