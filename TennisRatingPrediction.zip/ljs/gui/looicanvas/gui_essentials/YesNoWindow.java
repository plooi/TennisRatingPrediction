/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ljs.gui.looicanvas.gui_essentials;

import ljs.gui.looicanvas.utilities.InputAction;

/**
 *
 * @author peter_000
 */
public class YesNoWindow extends ButtonWindow
{
    
    public YesNoWindow(InputAction<ButtonWindow>[] actions) 
    {
        super(new String[] {"Yes,No"}, actions);
    }
    
}
