/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ljs.gui.looicanvas.three_dimensional;
import java.awt.Color;
import java.util.ArrayList;
import ljs.gui.looicanvas.LooiObject;
import ljs.gui.looicanvas.utilities.Supplier;

/**
 *
 * @author peter_000
 */
public abstract class Object3D extends LooiObject implements Component3D
{
    public static final Color DEFAULT_COLOR = Color.BLACK;
    private double horizontalRotation;
    private ArrayList<Component3D> visuals = new ArrayList<>();
    private ArrayList<Point3D> points = new ArrayList<>();
    private Point3D center;
    private boolean needsSetup = true;
    private Supplier<View> view;
    public Object3D(Supplier<View> view, Point3D center)
    {
        this.view = view;
        this.center = center;
    }
    
    protected abstract void setup();
    public Color getColor()
    {
        return DEFAULT_COLOR;
    }
    protected void looiStep()
    {
        super.looiStep();
        if(needsSetup)
        {
            needsSetup = false;
            setup();
            setHR(getHR());
        }
    }
    public Point3D getCenter(){return center;}
    protected Supplier<View> getView(){return view;}
    protected Point3D getPoint(int index){return points.get(index);}
    protected void setPoint(int index, Point3D point)
    {
        while(!(index < points.size()))
        {
            points.add(null);
        }
        points.set(index,point);
        if(center == null)
        {
            center = point;
        }
    }
    protected Component3D getVisual(int index){return visuals.get(index);}
    protected void setVisual(int index, Component3D component)
    {
        while(!(index < visuals.size()))
        {
            visuals.add(null);
        }
        visuals.set(index,component);
        add((LooiObject)component);
    }
    protected void setVisual(int index, Color c, int...indicies)
    {
        Point3D[] points = new Point3D[indicies.length];
        for(int i = 0; i < points.length; i++)
        {
            points[i] = getPoint(indicies[i]);
        }
        setVisual(index, new Polygon3D(c,view,points));
    }
    protected int getNumPoints(){return points.size();}
    protected int getNumVisuals(){return visuals.size();}
    public double getHR(){return horizontalRotation;}
    public void setHR(double d)
    {
        //System.out.println(d + ", " + this);
        double difference = d - horizontalRotation;
        horizontalRotation = d;
        for(Point3D p : points)
        {
            
            if(p instanceof RelativePoint)
            {
                RelativePoint r = (RelativePoint)p;
                r.getVector().setHR(r.getBaseVector().getHR() + horizontalRotation); 
            }
        }
        
        for(Component3D c : visuals)
        {
            if(c instanceof Object3D)
            {
                ((Object3D)c).setHR(((Object3D)c).getHR() + difference);
            }
        }
    }
    public static Vector right(double mag){return new Vector(0,0,mag);}
    public static Vector left(double mag){return new Vector(180,0,mag);}
    public static Vector forward(double mag){return new Vector(90,0,mag);}
    public static Vector backward(double mag){return new Vector(270,0,mag);}
    public static Vector up(double mag){return new Vector(0,90,mag);}
    public static Vector down(double mag){return new Vector(0,270,mag);}
    
}
