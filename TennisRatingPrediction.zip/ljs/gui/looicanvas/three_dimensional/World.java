/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ljs.gui.looicanvas.three_dimensional;


import java.awt.Color;
import java.io.Serializable;
import java.util.ArrayList;
import ljs.gui.looicanvas.LooiObject;
import ljs.gui.looicanvas.utilities.Supplier;
import ljs.gui.looicanvas.utilities.TwoInsOneOut;

/**
 *
 * @author peter_000
 */
public class World 
{
    public static final Color TRANSPARENT_COLOR = new Color(0,0,0,0);
    public static final double 
            DEFAULT_MEDIUM_BLUR_DISTANCE = 3500,
            DEFAULT_HIGH_BLUR_DISTANCE = 5000,
            DEFAULT_DISAPPEAR_DISTANCE = 6500;
    private String name;
    private int 
            rows,
            columns,
            containerSideLengthInFloors;
    private double
            worldLength,
            worldDepth,
            mediumBlurDistance = DEFAULT_MEDIUM_BLUR_DISTANCE,
            highBlurDistance = DEFAULT_HIGH_BLUR_DISTANCE,
            disappearDistance = DEFAULT_DISAPPEAR_DISTANCE,
            unitSideLength;
    private Container[][] containers;
    private Floor[][] floors;
    private ArrayPoint[][] 
            points,
            containerPoints;
    private TwoInsOneOut<Integer,Integer,Double> terrainGeneration;
    private TwoInsOneOut<Integer,Integer,Color> floorColorGeneration;
    private ArrayList<LooiObject> myObjects = new ArrayList<>();
    private Container deadContainer = new Container()//deadContainer is the container that contains objects that are outside the terrain grid
        {

            @Override
            protected void looiStep(){}
            @Override
            public void activateContainedObjs(){}
        };
    public TwoInsOneOut<Integer,Integer,Color> getFloorColorGeneration(){return floorColorGeneration;}
    public TwoInsOneOut<Integer,Integer,Double> getTerrainGeneration(){return terrainGeneration;}
    public Container[][] getContainers(){return containers.clone();}
    public Floor[][] getFloors(){return floors.clone();}
    public ArrayPoint[][] getPoints(){return points.clone();}
    public ArrayPoint[][] getContainerPoints(){return containerPoints.clone();}
    public double getWorldLength(){return worldLength;}
    public double getWorldDepth(){return worldDepth;}
    public double getUnitSideLength(){return unitSideLength;}
    public double getMediumBlurDistance(){return mediumBlurDistance;}
    public double getHighBlurDistance(){return highBlurDistance;}
    public double getDisappearDistance(){return disappearDistance;}
    
    public World(String name, int rows, int columns, double unitSideLength, int containerSideLengthInFloors, TwoInsOneOut<Integer,Integer,Double> terrainGeneration, TwoInsOneOut<Integer,Integer,Color> floorColorGeneration, Supplier<View> view)
        {
            this.name = name;
            this.rows = rows;
            this.columns = columns;
            this.containerSideLengthInFloors = containerSideLengthInFloors;
            this.terrainGeneration = terrainGeneration;
            this.floorColorGeneration = floorColorGeneration;
            this.unitSideLength = unitSideLength;
            worldLength = columns * unitSideLength;
            worldDepth = rows * unitSideLength;

            floors = new Floor[rows][columns];
            containers = new Container[rows/containerSideLengthInFloors+1][columns/containerSideLengthInFloors+1];
            points = new ArrayPoint[rows+1][columns+1];
            containerPoints = new ArrayPoint[containers.length + 1][containers[0].length + 1];

            //Create container points
            for(int r = 0; r < containerPoints.length; r++)
                {
                    for(int c = 0; c < containerPoints[0].length; c++)
                        {
                            ArrayPoint newArrayPoint = new ArrayPoint(r * containerSideLengthInFloors,c * containerSideLengthInFloors,unitSideLength);
                            containerPoints[r][c] = newArrayPoint;
                            try
                                {
                                    points[r*containerSideLengthInFloors][c*containerSideLengthInFloors] = newArrayPoint;
                                }catch(ArrayIndexOutOfBoundsException e){}//System.out.println("Just a couple points obo because they are out of bounds points");}
                        }
                }

            //Create all other points
            for(int r = 0; r < points.length; r++)
                {
                    for(int c = 0; c < points[0].length; c++)
                        {
                            if(points[r][c] == null)
                                {
                                    points[r][c] = new ArrayPoint(r,c,unitSideLength);
                                }
                        }
                }

            //Generate terrain
            for(int r = 0; r < points.length; r++)
                {
                    for(int c = 0; c < points.length; c++)
                        {
                            points[r][c].setY(terrainGeneration.make(r,c));
                        }
                }



            //Make containers

            for(int r = 0; r < containers.length; r++)
                {
                    for(int c = 0; c < containers[0].length; c++)
                        {
                            containers[r][c] = new Container(this,containerPoints[r][c],containerPoints[r][c+1],containerPoints[r+1][c+1],containerPoints[r+1][c],mediumBlurDistance,highBlurDistance,disappearDistance,view);
                        }
                }

            //Make floors
            for(int r = 0; r < floors.length; r++)
                {
                    for(int c = 0; c < floors[0].length; c++)
                        {

                            floors[r][c] = new Floor(points[r][c],points[r][c+1],points[r+1][c+1],points[r+1][c],this,floorColorGeneration.make(r,c),view);
                            Point3D p = points[r][c];
                            //System.out.println(p.getX() + ","+p.getY()+","+p.getZ() + " at " + r + ", " +c);
                        }
                }
            activate();
        }
    public void activate()
        {
            //Activate containers
            for(int r = 0; r < containers.length; r++)
                {
                    for(int c = 0; c < containers[0].length; c++)
                        {
                            //com.looi.looi.Looi.mainWindow.activate(containers[r][c]);
                            containers[r][c].activate();
                        }
                }
            for(LooiObject l : myObjects)//myObjects should contain container-like objects
            {
                l.activate();
            }
        }
    public void addObject(LooiObject l)
        {
            myObjects.add(l);
        }
    public void removeObject(LooiObject l)
        {
            myObjects.remove(l);
        }
    public class ArrayPoint extends Point3D implements Serializable
        {

            private int row;//If it is a container point, but you want to find the row and column in the real point array, simply 
            private int column;//row * containerSideLength = real point array row
            private boolean outOfBoundsPoint;

            public ArrayPoint(int row, int column, double unitSideLength)
                {
                    super(column*unitSideLength,0,-row*unitSideLength);
                    this.row = row;
                    this.column = column;
                    this.outOfBoundsPoint = getX() > worldLength || -getZ() > worldDepth;
                }
            public int getRow()
                {
                    return row;
                }
            public int getColumn()
                {
                    return column;
                }

            public int getContainerRow()
                {
                    return row / containerSideLengthInFloors;
                }
            public int getContainerColumn()
                {
                    return column / containerSideLengthInFloors;
                }
            public boolean isOutOfBounds()
                {
                    return outOfBoundsPoint;
                }
        }
    public Container getCorrectContainer(Point3D location)
        {
            double x = location.getX();
            double z = location.getZ();
            int row = (int)(-z/(containerSideLengthInFloors*unitSideLength));
            int column = (int)(x/(containerSideLengthInFloors*unitSideLength));
            //System.out.println(containers[0].length + " long container trying to access index " + column);
            //System.out.println(worldLength +" long world and a point at " + x);
            try
                {
                    return containers[row][column];
                }
            catch(ArrayIndexOutOfBoundsException e)
                {
                    return deadContainer;
                }
        }
    public Floor getCorrectFloor(Point3D location)
        {
            double x = location.getX();
            double z = location.getZ();
            int row = (int)(-z/(unitSideLength));
            int column = (int)(x/(unitSideLength));
            try
                {
                    return floors[row][column];
                }
            catch(ArrayIndexOutOfBoundsException e)
                {
                    return null;
                }
        }
    public void setMediumBlurDistance(double d)
        {
            mediumBlurDistance = d;
            for(Container[] cs : containers)
                {
                    for(Container c : cs)
                        {
                            c.getMediumBlur().setMinDistance(d);
                            c.getNoBlur().setMaxDistance(d); 
                        }
                }
        }
    public void setHighBlurDistance(double d)
        {
            highBlurDistance = d;
            for(Container[] cs : containers)
                {
                    for(Container c : cs)
                        {
                            c.getMediumBlur().setMaxDistance(d);
                            c.getHighBlur().setMinDistance(d); 
                        }
                }
        }
    public void setDisappearDistance(double d)
        {
            disappearDistance = d;
            for(Container[] cs : containers)
                {
                    for(Container c : cs)
                        {
                            c.getHighBlur().setMaxDistance(d); 
                        }
                }
        }
    public void scaleToNewDisappearDistance(double d)
    {
        for(Container[] cs : containers)
            {
                for(Container c : cs)
                    {
                        c.scaleToNewDisappearDistance(d);
                    }
            }
    }
    public Color findAvgColor(int startRow, int startCol, int oneAfterEndRow, int oneAfterEndCol)
        {
            int totalR = 0;
            int totalG = 0;
            int totalB = 0;
            int totalQuadrilaterals = 0;
            for(int r = startRow; r < oneAfterEndRow; r++)
                {
                    for(int c = startCol; c < oneAfterEndCol; c++)
                        {
                            try
                            {
                                Component3D q = floors[r][c];
                                totalR += q.getColor().getRed();
                                totalG += q.getColor().getGreen();
                                totalB += q.getColor().getBlue();
                                totalQuadrilaterals++;
                            }
                            catch(ArrayIndexOutOfBoundsException e)
                            {

                            }

                        }
                }
            if(totalQuadrilaterals == 0)
                {
                    return TRANSPARENT_COLOR;
                }
            int avgR = totalR / totalQuadrilaterals;
            int avgG = totalG / totalQuadrilaterals;
            int avgB = totalB / totalQuadrilaterals;
            return new Color(avgR,avgG,avgB);
        }
    
    
    
}
