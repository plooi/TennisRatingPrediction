/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ljs.gui.looicanvas.three_dimensional;

import java.io.Serializable;

/**
 *
 * @author peter_000
 */
public class Vector implements Serializable
    {
        private double hr,vr,mag;
        public Vector(double hr, double vr, double mag)
            {
                this.hr = hr;
                this.vr = vr;
                this.mag = mag;
            }
        
        public double getHR()
            {
                return hr;
            }
        public double getVR()
            {
                return vr;
            }
        public double getMag()
            {
                return mag;
            }
        public void setHR(double d){hr = d;}
        public void serVR(double d){vr = d;}
        public void setMag(double d){mag = d;}
        public Vector clone()
            {
                return new Vector(hr,vr,mag);
            }
        
    }
