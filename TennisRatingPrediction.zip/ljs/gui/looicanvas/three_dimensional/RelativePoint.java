/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ljs.gui.looicanvas.three_dimensional;

import static ljs.gui.looicanvas.Calculations.cos;
import static ljs.gui.looicanvas.Calculations.sin;


/**
 *
 * @author peter_000
 */
public class RelativePoint extends Point3D
{
    private Point3D startPoint;
    private Vector vector;
    private Vector baseVector;//rotation = 0
    private double concretePointX,concretePointY,concretePointZ,vectorhr,vectorvr,vectormag;//this is where the relative points remember where the concrete point was the last time this object's coordinates were accessed
    public Vector getVector(){return vector;}
    public Vector getBaseVector(){return baseVector;}
    public RelativePoint(Point3D startPoint, Vector vector) 
    {
        super(0,0,0);
        this.startPoint = startPoint;
        this.vector = vector;
        this.baseVector = vector.clone();
//        Point3D concretePoint = getConcretePoint();
//        concretePointX = concretePoint.getX();
//        concretePointY = concretePoint.getY();
//        concretePointZ = concretePoint.getZ();
        concretePointX = getConcretePoint().getX() + 100;//make sure that we update down the chain;
        updateDownTheChain();
    }
    public double[] getXYZ()
    {
        
        updateDownTheChain();//if this is not necessary, it is not a costly method call
        return new double[] {super.getX(),super.getY(),super.getZ()};
    }
    public void updateDownTheChain()
    {
        Point3D concretePoint = getConcretePoint();
        boolean concretePointHasChanged = (concretePointX != concretePoint.getX()) || (concretePointY != concretePoint.getY()) || (concretePointZ != concretePoint.getZ()) || (vectorhr != vector.getHR()) || (vectorvr != vector.getVR()) || (vectormag != vector.getMag());
        if(concretePointHasChanged)
        {
            //if concret point has moved some, then I don't know where I actually should be, so I will ask my start point to update himself, so then I will know where I am because I know my vector. If startPoint is the concretePoint, then I will forget the updation, because he can't.
            
            
            if(startPoint instanceof RelativePoint)
            {
                ((RelativePoint)startPoint).updateDownTheChain();
            }
            this.applyToVector(startPoint,vector);
        }
        concretePointX = concretePoint.getX();
        concretePointY = concretePoint.getY();
        concretePointZ = concretePoint.getZ();
        vectorhr = vector.getHR();
        vectorvr = vector.getVR();
        vectormag = vector.getMag();
    }
    public double getX(){updateDownTheChain(); return super.getX();}
    public double getY(){updateDownTheChain(); return super.getY();}
    public double getZ(){updateDownTheChain(); return super.getZ();}
    protected Point3D getConcretePoint()
    {
        if(startPoint instanceof RelativePoint)
        {
            return ((RelativePoint)startPoint).getConcretePoint();
        }
        else
        {
            return startPoint;
        }
    }
    
    
    public void applyToVector(Point3D center, Vector vector)
    {
        double distance = vector.getMag();
        double newDeltaX = cos(vector.getHR()) * distance * cos(vector.getVR());
        double newDeltaZ = sin(vector.getHR()) * distance * cos(vector.getVR());
        double newDeltaY = -sin(vector.getVR()) * distance;
        this.setXYZ(center.getX() + newDeltaX,center.getY() + newDeltaY,center.getZ() + newDeltaZ);
    }
    
    
}
