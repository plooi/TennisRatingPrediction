/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ljs.gui.looicanvas.three_dimensional;

import ljs.gui.looicanvas.utilities.Supplier;


/**
 *
 * @author peter_000
 */
public abstract class ContainedObject extends WorldObject
{
    private Container myContainer;
    public ContainedObject(Supplier<View> view, Point3D center, World myWorld) 
    {
        super(view,center,myWorld);
        checkContainerSwitch();
    }
    public void checkContainerSwitch()
        {
            /*if(myContainer != null)
                {
                    myContainer.removeObject(this);
                }
            myContainer = getMyWorld().getCorrectContainer(getCenter());
            myContainer.addObject(this);*/
            Container c = getMyWorld().getCorrectContainer(getCenter());
            if(c != myContainer)
                {
                    if(myContainer != null)
                        {
                            myContainer.getNoBlur().remove(this);
                        }

                    myContainer = c;
                    if(myContainer != null)
                        {
                            myContainer.getNoBlur().add(this);
                        }
                }
        }
    protected void looiStep()
    {
        super.looiStep();
        checkContainerSwitch();
    }
    protected Container getMyContainer(){return myContainer;}

    
}
