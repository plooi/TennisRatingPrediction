/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package looinn;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author peter_000
 */
public abstract class NeuralNetworkEvolver 
{
    private NeuralNetwork nn;
    private HashMap<double[],double[]> data = new HashMap<>();
    public NeuralNetworkEvolver(NeuralNetwork nn)
    {
        this.nn = nn;
    }
    public void save(){nn.save();}
    public HashMap<double[],double[]> getData(){return data;}
    public NeuralNetwork getNN(){return nn;}
    public void addData(double[] in, double[] out)
    {
        data.put(in,out);
    }
    public void addData(String fileName)
    {
        try
        {
            FileInputStream fis = new FileInputStream(fileName);
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);
            String line = "";
            while((line = br.readLine()) != null)
            {
                
                ArrayList<Double> input = new ArrayList<>();
                ArrayList<Double> output = new ArrayList<>();
                String before = line.substring(0,line.indexOf("->"));
                String after = line.substring(line.indexOf("->") + 2);
                while(before.length() > 0)
                {
                    if(before.contains(","))
                    {
                        double in = Double.parseDouble(before.substring(0,before.indexOf(",")));
                        before = before.substring(before.indexOf(",")+1);
                        input.add(in);
                    }
                    else
                    {
                        double in = Double.parseDouble(before);
                        before = "";
                        input.add(in);
                    }
                    
                }
                while(after.length() > 0)
                {
                    
                    if(after.contains(","))
                    {
                        double out = Double.parseDouble(after.substring(0,after.indexOf(",")));
                        after = after.substring(after.indexOf(",")+1);
                        output.add(out);
                    }
                    else
                    {
                        double out;
                        if(after.contains("#"))
                        {
                            out = Double.parseDouble(after.substring(0,after.indexOf("#")));
                        }
                        else
                        {
                            out = Double.parseDouble(after);
                        }
                        after = "";
                        output.add(out);
                    }
                }
                double[] in = new double[input.size()];
                double[] out = new double[output.size()];
                for(int i = 0; i < input.size(); i++)
                    in[i] = input.get(i);
                for(int i = 0; i < output.size(); i++)
                    out[i] = output.get(i);
                data.put(in,out);
            }
            br.close();
        }
        catch(IOException e)
        {
            e.printStackTrace();
            throw new RuntimeException();
        }
        
    }
    public abstract String evolve();
}
