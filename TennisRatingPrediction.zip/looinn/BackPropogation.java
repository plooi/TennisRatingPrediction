/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package looinn;

import java.awt.Button;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import javax.swing.JFrame;

/**
 *
 * Same as BackPropogation, but for this one it only bothers orderine the weights once, and then starts updating the weights in that order. Once
 *  all weights are updated, then it reorders them again. This
 * BackPropogation2 doesn't waste time reordering the weights after each individual weight has been adjusted.
 */
public class BackPropogation extends NeuralNetworkEvolver
{
    
    private double slopeFindingDelta = .00000001;
    private double weightInc = .001;
    private double aboutZeroSlope = .00001;
    private double aboutZeroError = .01;
    private int printPeriod = 1000;//on which weight increments does it print a weight increment update?
    private int roundPrintPeriod = 1;//on which rounds does it print a round update?
    private int weightOrderingPrintPeriod = 20;
    
    
    private boolean running = true;
    public void setRunning(boolean running){this.running = running;}
    
    public BackPropogation(NeuralNetwork nn) 
    {
        super(nn);
    }

    @Override
    public String evolve()
    {
        return evolve(true);
    }
    
    
    
    
    /*
    This is the best back propogation algorithm in the world. It works, because even when it's
    in a narrow, diagonal canyon, each of the weight adjustments actually overshoots slightly. 
    That's how it keeps descending down the canyon!
    */
    public String evolve(boolean print) //order the weights once, but dont order them again until they've all been updated
    {
        
        
        System.out.println("Evolution starting");
        double[][][] weights = getNN().getWeights();
        double leastError = Double.MAX_VALUE;
        double[][][] bestWeights = null;
        
        int roundCounter = 0;
        while(true)//for each weight in order from steepest to shallowest, optimize them all fully. Do this forever
        {
            roundCounter++;
            
            
            ArrayList<int[]> indexesInOrder = new ArrayList<>();
            ArrayList<Double> slopesInOrder = new ArrayList<>();
            
            if(print)
                System.out.println("Ordering weights");
            int weightOrderingCount = 0;
            for(int r = 0; r < weights.length; r++)
                for(int c = 0; c < weights[r].length; c++)
                    for(int d = 0; d < weights[r][c].length; d++)
                    {
                        weightOrderingCount++;
                        double slope = getNN().slope(r,c,d,slopeFindingDelta,getData());
                        int[] index = {r,c,d};
                        int insertionIndex = -1;
                        for(int i = 0; i < slopesInOrder.size(); i++)
                        {
                            if(Math.abs(slopesInOrder.get(i)) < Math.abs(slope))
                            {
                                insertionIndex = i;
                                break;
                            }
                        }
                        if(insertionIndex == -1)
                            insertionIndex = slopesInOrder.size();
                        
                        slopesInOrder.add(insertionIndex,slope);
                        indexesInOrder.add(insertionIndex,index);
                        if(weightOrderingCount % weightOrderingPrintPeriod == 0 && print)
                            System.out.println("Ordering weight r:" + r + " c: " + c + " d: " + d);
                    }
            for(int[] weightIndex : indexesInOrder)//iterate through each weight
            {
                if(!running)
                {
                    
                    if(leastError < error())//set the weights to the best weights if the best weights are not these weights
                        setWeights(bestWeights);
                    int save = getNN().save();//last lines of code in this method here
                    System.out.println("Evolution stopped because you told me to. Final error: " + error());
                    System.out.println("Save number: " + save);
                    return "Evolution stopped you told me to. Final error: " + error() + " Save number: " + save;//last lines of code in this method here
                }
                int r = weightIndex[0];
                int c = weightIndex[1];
                int d = weightIndex[2];
                
                double slope = getNN().slope(r,c,d,slopeFindingDelta,getData());// find the slope
                double slopePositivity = Math.signum(slope);//and the slope positivity
                
                int printCounter = 0;
                while(true)//fully adjust the weight, until the slope positivity changes
                {
                    
                    printCounter++;
                    if(slopePositivity == 1)//increment the weight in the correct direction
                    {
                        getNN().incWeight(r,c,d,-weightInc);
                    }
                    else
                    {
                        getNN().incWeight(r,c,d,weightInc);
                    }
                    slope = getNN().slope(r,c,d,slopeFindingDelta,getData());//find the new slope, to check if we should stop or not
                    if(print && printCounter%printPeriod == 1)
                        System.out.println("Descending gradient on r = " + r +" c = " + c + " d = " + d +"; Error: " + error());
                    if(Math.signum(slope) != slopePositivity || slope <= aboutZeroSlope)//if the slope direction changes, break;
                    {
                        break;
                    }
                    if(Math.abs(slope) <= aboutZeroSlope)
                    {
                        break;
                    }
                    if(error() <= aboutZeroError)//check if we've achieved our goal
                    {
                        System.out.println("Evolution stopped because the error is pretty much zero. Final error: " + error());
                        int save = getNN().save();//last lines of code in this method here
                        System.out.println("Save number: " + save);
                        return "Evolution stopped because the error is pretty much zero. Final error: " + error() + " Save number: " + save;//last lines of code in this method here
                    }   
                }   
            }
            double error = error();
            
            if(error <= aboutZeroError)//check if we've achieved out goal
            {
                System.out.println("Evolution stopped because the error is pretty much zero. Final error: " + error());
                int save = getNN().save();//last lines of code in this method here
                System.out.println("Save number: " + save);
                return "Evolution stopped because the error is pretty much zero. Final error: " + error() + "Save number: " + save;//last lines of code in this method here
            }
            else if(error >= leastError)//going uphill!
            {
                //we're going backwards
                setWeights(bestWeights);
                System.out.println("Evolution stopped because we started going uphill altogether. Final error: " + error());
                int save = getNN().save();//last lines of code in this method here
                System.out.println("Save number: " + save);
                return "Evolution stopped because we started going uphill altogether. Final error: " + error() + " Save number: " + save;//last lines of code in this method here
            }
            else//descending gradient
            {
                leastError = error;
                if(print && roundCounter%roundPrintPeriod == 0)
                    System.out.println("Round has finished. Descending gradient. Error: " + error);
                bestWeights = copy(weights);
            }
        }
        
    }
    public double[][][] copy(double[][][] a)
    {
        double[][][] ret = new double[a.length][][];
        /*for(int i = 0; i < a.length; i++)
        {
            ret[i] = a[i];//haha, get it? a[i]? AI? ahahahhaha...
        }*/
        for(int r = 0; r < ret.length; r++)
        {
            ret[r] = new double[a[r].length][];
            for(int c = 0; c < ret[r].length; c++)
            {
                ret[r][c] = new double[a[r][c].length];
            }
        }
        for(int r = 0; r < ret.length; r++)
            for(int c = 0; c < ret[r].length; c++)
                for(int d = 0; d < ret[r][c].length; d++)
                    ret[r][c][d] = a[r][c][d];
        return ret;
    }
    public void setWeights(double[][][] newWeights)
    {
        double[][][] weights = getNN().getWeights();
        for(int r = 0; r < weights.length; r++)
            for(int c = 0; c < weights[r].length; c++)
                for(int d = 0; d < weights[r][c].length; d++)
                    getNN().setWeight(r,c,d,newWeights[r][c][d]);
    }
    /*public double slopeOld(int r, int c, int d)//old... I have more mental confidence in the accuracy of this method... although I know for a fact the other one works
    {
        double[][][] weights = getNN().getWeights();
        double x1 = weights[r][c][d];
        //System.out.println(getNN());
        double y1 = error();
        weights[r][c][d] += slopeFindingDelta;
        double x2 = weights[r][c][d];
        //System.out.println(getNN());
        double y2 = error();
        weights[r][c][d] = x1;
        //System.out.println("y2 " + y2 + " y1 " + y1 + " x2 " + x2 + " x1 " + x1);
        return (y2 - y1)/(x2 - x1);
    }*/
    
    public double error()
    {
        //System.out.println(getNN());
        double error = 0;
        for(double[] input : getData().keySet())
        {
            double[] output = getData().get(input);
            double[] experimentalOutput = getNN().evaluate(input);
            //System.out.println("Exp: " + experimentalOutput + " Cor: " + output[0]);
            error += squaredError(output,experimentalOutput);
            
        }
        //System.out.println("err: " + error);
        //System.out.println(error);
        return error;
    }
    public double squaredError(double[] correct, double[] experimental)
    {
        double error = 0;
        if(correct.length > experimental.length)
            throw new RuntimeException("Correct length: " + correct.length + " Experimental length: " + experimental.length + ". Correct length cannot be greater than experimental length.");
        for(int i = 0; i < correct.length; i++)
        {
            error += (correct[i] - experimental[i])*(correct[i] - experimental[i]);
        }
        return error;
    }
}

/*
public void evolve(boolean print)
{
        System.out.println("Evolution starting");
        double[][][] weights = getNN().getWeights();
        double leastError = Double.MAX_VALUE;
        double[][][] bestWeights = null;
        class Index3D
        {
            public final int r,c,d;
            public Index3D(int r, int c, int d){this.r=r;this.c=c;this.d=d;}
            public boolean containedIn(ArrayList<Index3D> arr)
            {
                for(Index3D i : arr)
                {
                    if(i.r == r && i.c == c && i.d == d)
                    {
                        return true;
                    }
                }
                return false;
            }
        }
        int roundCounter = 0;
        while(true)//for each weight, optimize it fully. Do this forever
        {
            roundCounter++;
            ArrayList<Index3D> weightsUsed = new ArrayList<>();
            
            while(true)//iterate through each weight
            {
                double largestSlope = 0;Index3D index = null;
                
                if(print)
                    System.out.println("Finding weight with greatest slope");
                for(int r = 0; r < weights.length; r++)//find the weight with the biggest slope that hasnt been updated yet
                {
                    for(int c = 0; c < weights[r].length; c++)
                    {
                        for(int d = 0; d < weights[r][c].length; d++)
                        {
                            if(print && Math.random()<.01)
                                System.out.println("Find slope of weight r: " + r + " c: " + c +" d: " + d);
                            //System.out.println("r"+r + " c" + c +" d" + d);
                            double slope = slope(r,c,d);
                            Index3D index3D = new Index3D(r,c,d);
                            if(Math.abs(slope) >= Math.abs(largestSlope) && !index3D.containedIn(weightsUsed))
                            {
                                largestSlope = slope;
                                index = index3D;
                            }
                        }
                    }
                }
                if(index == null)//this means we have already fully updated all the weights. Time to break out of here, and go for another round, starting with the steepest weight again
                {
                    break;
                }
                //now we have determined that largestSlope holds the largest slope (of unused neurons), and index holds its index.
                weightsUsed.add(index);
            
            
            
                double slope = slope(index.r,index.c,index.d);
                double slopePositivity = Math.signum(slope);//1 or -
                int printCounter = 0;
                
                while(true)//fully adjust the weight
                {
                    
                    printCounter++;
                    if(slopePositivity == 1)
                    {
                        weights[index.r][index.c][index.d] -= weightInc;
                    }
                    else
                    {
                        weights[index.r][index.c][index.d] += weightInc;
                    }
                    slope = slope(index.r,index.c,index.d);
                    if(print && printCounter%printPeriod == 0)
                        System.out.println("Descending gradient on r = " + index.r +" c = " + index.c + " d = " + index.d +"; Error: " + error());
                    if(Math.signum(slope) != slopePositivity || slope <= aboutZeroSlope)//if the slope direction changes, break;
                    {
                        break;
                    }
                    
                    if(error() <= aboutZeroError)//check if we've achieved out goal
                    {
                        System.out.println("Evolution stopped because the error is pretty much zero. Final error: " + error());
                        int save = getNN().save();//last lines of code in this method here
                        System.out.println("Save number: " + save);
                        return;//last lines of code in this method here
                    }
                    
                }
                
                
            }
            double error = error();
            
            if(error <= aboutZeroError)//check if we've achieved out goal
            {
                System.out.println("Evolution stopped because the error is pretty much zero. Final error: " + error());
                int save = getNN().save();//last lines of code in this method here
                System.out.println("Save number: " + save);
                return;//last lines of code in this method here
            }
            if(error >= leastError)//going uphill!
            {
                //we're going backwards
                setWeights(bestWeights);
                System.out.println("Evolution stopped because we started going uphill altogether. Final error: " + error());
                int save = getNN().save();//last lines of code in this method here
                System.out.println("Save number: " + save);
                return;//last lines of code in this method here
            }
            else//descending gradient
            {
                leastError = error;
                if(print && roundCounter%roundPrintPeriod == 0)
                    System.out.println("Round has finished. Descending gradient. Error: " + error);
                bestWeights = copy(weights);
            }
        }
        
    }
*/