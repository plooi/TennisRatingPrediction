/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package looinn;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.io.Serializable;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author peter_000
 */
public class NeuralNetwork implements Serializable
{
    private static final long serialVersionUID = 31415926;
    private double[][][] weights;
    private ActivationFunction activation;
    private IntBoolean canActivateBasedOnColumn;
    private int numInputs;
    private HashMap<double[],double[][]> evaluationTable = new HashMap<>();//<input:values/*row 1 is input*/>
    private boolean activateOnLastLayer;
    
    
    public static interface WeightGeneration
    {
        public double gen(int r,int c,int d);
    }
    public static interface IntBoolean extends Serializable
    {
        public boolean check(int i);
    }
    public static NeuralNetwork deserialize(String fileName)
    {
        
        try
        {
            FileInputStream fis = new FileInputStream(fileName);
            ObjectInputStream ois = new ObjectInputStream(fis);
            return (NeuralNetwork)ois.readObject();
        }catch(IOException|ClassNotFoundException e){e.printStackTrace();throw new RuntimeException("Invalid or nonexistent file.");}
    }
    /*Constructors here!*/
    
    public static final IntBoolean DEFAULT_ACTIVATE_EVERY_OTHER = (c)->c%2==1;
    public NeuralNetwork(boolean activateOnLastLayer, ActivationFunction activation, IntBoolean canActivateBasedOnColumn, WeightGeneration w, int numInputs, int...lengths)//this neural network only activates every OTHER neuron in each row! Beware! (btw, this GREATLY increases accuracy)    
    {
        this.canActivateBasedOnColumn = canActivateBasedOnColumn;
        this.activateOnLastLayer = activateOnLastLayer;
        this.numInputs = numInputs;
        this.activation = activation;
        weights = new double[lengths.length][][];
        for(int r = 0; r < lengths.length; r++)//initialize in the array dimensions appropriately
        {
            if(r == 0)//first row
            {
                //r == 0
                weights[r] = new double[lengths[r]][numInputs + 1];// + 1 for the bias
            }
            else
            {
                weights[r] = new double[lengths[r]][lengths[r - 1] + 1];//[length of row][depth of row, same as last row]// + 1 for the bias
            }
        }
        
        for(int r = 0; r < weights.length; r++)//assign starting values
            for(int c = 0; c < weights[r].length; c++)
                for(int d = 0; d < weights[r][c].length; d++)
                {
                    weights[r][c][d] = w.gen(r,c,d);
                }
    }
    
    
    /**
     * WARNING! DO NOT USE THIS REFERENCE TO UPDATE THE WEIGHTS
     * @return 
     */
    public double[][][] getWeights(){return weights;}
    
    
    
    public double slope(int r, int c, int d, double slopeFindingDelta, Map<double[],double[]> data)
    {
        double x1 = weights[r][c][d];
        double error1 = 0;
        
        for(double[] input : data.keySet())
        {
            double[] correct = data.get(input);
            double[] experimental = evaluate(input);
            for(int i = 0; i < correct.length; i++)
            {
                error1 += ( correct[i]-experimental[i] ) * ( correct[i]-experimental[i] );
            }
        }
        double y1 = error1;
        incWeight(r,c,d,slopeFindingDelta);
        
        
        double x2 = weights[r][c][d];
        double error2 = 0;
        for(double[] input : data.keySet())
        {
            double[] correct = data.get(input);
            double[] experimental = evaluate(input);
            for(int i = 0; i < correct.length; i++)
            {
                error2 += ( correct[i]-experimental[i] ) * ( correct[i]-experimental[i] );
            }
        }
        double y2 = error2;
        setWeight(r,c,d,x1);
        return (y2 - y1)/(x2 - x1);
    }
    
    
    /*
    Increments the weight, and then updates all the weights below for every input output pair
    use this method (inc weight) and setweight to increment the weights. Not the direct reference to weights array
    */
    public void incWeight(int r, int c, int d, double inc)
    {
        weights[r][c][d] += inc;
        for(double[] input : evaluationTable.keySet())
        {
            update(r,c,input);
            updateDown(r+1,input);
        }
    }
    public void setWeight(int r, int c, int d, double weight)
    {
        weights[r][c][d] = weight;
        for(double[] input : evaluationTable.keySet())
        {
            update(r,c,input);
            updateDown(r+1,input);
        }
    }      
    
    public void update(int r, int c, double[] input)
    {
        double weightedSum = 0;
        double[][] values = evaluationTable.get(input);
        for(int d = 0; d < weights[r][c].length - 1; d++)//go through each weight in the neuron, except the last one, which is bias
        {
            if(r == 0)//first row, get the values from the input
            {
                weightedSum += input[d] * weights[r][c][d];//input * weight
            }
            else//not first row, get the values from the row above
            {
                weightedSum += values[r - 1][d] * weights[r][c][d];//input * weight
            }
        }
        weightedSum += weights[r][c][  weights[r][c].length-1  ];//add a bias
        double activatedSum;
        if(r + 1 < values.length)//not last layer
        {
            if(canActivateBasedOnColumn.check(c))//every other layer activate
                activatedSum = activation.activate(weightedSum);//activate!!
            else
                activatedSum = weightedSum;
        }
        else//last layer
        {
            if(activateOnLastLayer)
                activatedSum = activation.activate(weightedSum);//activate!!
            else
            {
                //dont activate
                activatedSum = weightedSum;
            }
        }
        values[r][c] = activatedSum;
    }
    /*
    If I activate the 3rd row, then the 3rd row has to
    grab values up from the second row, input, times 
    weight, add a bias, activate. This method makes
    the nn start evaluating from the values of its last
    evaluation
    */
    public void updateDown(int firstRowActivated,double[] input)
    {
        double[][] values = evaluationTable.get(input);
        for(int r = firstRowActivated; r < values.length; r++)//go down the rows and input * weight, add a bias, activate
        {
            for(int c = 0; c < values[r].length; c++)//for each value in values:
            {
                double weightedSum = 0;
                for(int d = 0; d < weights[r][c].length - 1; d++)//go through each weight in the neuron, except the last one, which is bias
                {
                    if(r == 0)//first row, get the values from the input
                    {
                        weightedSum += input[d] * weights[r][c][d];//input * weight
                    }
                    else //not first row, get the values from the row above
                    {
                        weightedSum += values[r - 1][d] * weights[r][c][d];//input * weight
                    }
                }
                weightedSum += weights[r][c][  weights[r][c].length-1  ];//add a bias
                double activatedSum;
                if(r + 1 < values.length)//not last layer
                {
                    if(canActivateBasedOnColumn.check(c))//activate only at specific times
                        activatedSum = activation.activate(weightedSum);//activate!!
                    else
                        activatedSum = weightedSum;
                }
                else//last layer
                {
                    if(activateOnLastLayer)
                        activatedSum = activation.activate(weightedSum);//activate!!
                    else
                    {
                        //dont activate
                        activatedSum = weightedSum;
                    }
                }
                values[r][c] = activatedSum;
            }
        }
    }
    public double[] evaluate(int...input)
    {
        double[] conv = new double[input.length];
        for(int i = 0; i < input.length; i++)
        {
            conv[i] = input[i];
        }
        return evaluate(conv);
    }
    public double[] evaluate(double...input)//this evaluate method only activates every OTHER neuron in each row! Beware! (btw, this GREATLY increases accuracy)
    {
        
        if(!evaluationTable.keySet().contains(input))
        {
            double[][] values = new double[weights.length][];
            for(int r = 0; r < weights.length; r++)
            {
                values[r] = new double[weights[r].length];
            }
            evaluationTable.put(input,values);
            updateDown(0,input);
            //evaluationTable.put(input, values)
        }
        double[][] values = evaluationTable.get(input);
        
        return values[values.length - 1];
    }
    

    public String toString()
    {
        return Arrays.deepToString(weights);
    }
    public int save()
    {
        try
        {
            File saveIndex = new File("last_save_number.txt");
            int saveIndexNum = 0;
            if(saveIndex.exists())
            {
                FileInputStream fis = new FileInputStream(saveIndex);
                InputStreamReader isr = new InputStreamReader(fis);
                BufferedReader br = new BufferedReader(isr);
                saveIndexNum = Integer.parseInt(br.readLine()) + 1;
                br.close();
            }
            FileOutputStream fos = new FileOutputStream("last_save_number.txt");
            OutputStreamWriter osw = new OutputStreamWriter(fos);
            BufferedWriter br = new BufferedWriter(osw);
            br.write(""+saveIndexNum);
            br.close();
            
            FileOutputStream fos2 = new FileOutputStream("neuralnetwork"+saveIndexNum+".nn");
            ObjectOutputStream oos = new ObjectOutputStream(fos2);
            oos.writeObject(this);
            oos.close();
            return saveIndexNum;
        }
        catch(IOException e)
        {
            e.printStackTrace();
            throw new RuntimeException("Problem occurred. It was an IOException.");
        }
    }
    public static interface ActivationFunction extends Serializable
    {
        public double activate(double d);
    }
    public static final ActivationFunction LEAKY_RELU = (d)->//SURE??? I GUESS?
    {
        if(d >= 0)
            return d;
        else
            return d*.1;
    };
    public static final ActivationFunction SIGMOID = (d)->//NO, because the slopes drown out really fast
    {
        return 1/(1 + Math.pow(Math.E,-d));
    };
    public static final ActivationFunction ETOTHEX = (d)->{return Math.pow(Math.E,d);};//NO
    public static final ActivationFunction ETOTHEXCAPPED = (d)->//NO
    {
        if(d > 100)
        {
            d = 100;
        }
        return Math.pow(Math.E,d);
    };
    public static final ActivationFunction SIN = (d)->{return Math.sin(d/100);};//LIKE I GUESS IT COULD WORK
    public static final ActivationFunction LINEAR_WAVE = (d)->d + 10*Math.sin(d/300);//NOT REALLY...
    public static final ActivationFunction DO_NOTHING = (d)->d;//GOOD, make sure to set your slope finding delta relatively low
    public static final ActivationFunction SOFT_SIGMOID = (d)->
    {
        return 1/(1 + Math.pow(1.01,-d));
    };//GOOD. 
    public static final ActivationFunction SOFT_BELL = (d)->Math.pow(1.0005,-d*d);
}
